package mainFulbito;

import java.util.Scanner;
import servicio.JugadorServicio;

public class FulbitoMain {

    public static void main(String[] args) {

        /**
         * instanciamos el objero jugadorServicio como de la clase
         * jugadorservicio
         *
         */
        JugadorServicio jugadorServicio = new JugadorServicio();

        /**
         * instanciamos el objeto leer de la clase Scanner, para poder cargar
         * datos por pantalla y creamos un booleano para poder usarlo para salir
         * de nuestro programa
         */
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        boolean bucle = true;

        /**
         * Creamos un do- while para que nuestro menú se repita hasta que
         * nosotros lo finalicemos con la opción salir, tambien creaamos el
         * System.out.println() con el texto de nuestro menu
         *
         */
        do {
            System.out.println("Seleccione una opción:\n"
                    + "1.- Crear lista de Jugadores\n"
                    + "2.- Ocupar la lista PreCreada\n"
                    + "3.- Mostrar datos completos de los equipos\n"
                    + "4.- Salir");

            /**
             * Creamos un switch que elija según lo que ingresemos por teclado.
             * En nuestro ejemplo tenemos cuatro valores válidos (observa bien
             * que en este caso recibimos String, no int por ello es que en cada
             * case el número está entrecomillas)
             */
            switch (leer.next()) {

                /**
                 * En el case "1" ejecutamos el método crearlistaJugadores() de
                 * nuestro objeto jugadorServicio, cuando termina éste método
                 * llamamos al método sortearEquipos() del mismo objeto y
                 * finalmente llamamos al método mostrarEquipos() del mismo
                 * objeto, donde cada uno de estos métodos se ejecuta
                 */
                case "1":
                    jugadorServicio.crearlistaJugadores();
                    jugadorServicio.sortearEquipos();
                    jugadorServicio.mostrarEquipos();
                    break;

                /**
                 * En el case "2" ejecutamos el método listaPreCreada() de
                 * nuestro objeto jugadorServicio, cuando termina éste método
                 * llamamos al método sortearEquipos() del mismo objeto y
                 * finalmente llamamos al método mostrarEquipos() del mismo
                 * objeto, donde cada uno de estos métodos se ejecuta
                 */
                case "2":
                    jugadorServicio.listaPreCreada();
                    jugadorServicio.sortearEquipos();
                    jugadorServicio.mostrarEquipos();
                    break;
                /**
                 * En el case "3" ejecutamos el método mostrarEquiposCompletos()
                 * de nuestro objeto jugadorServicio
                 */
                case "3":
                    jugadorServicio.mostrarEquiposCompletos();
                    break;

                /**
                 * En el case "4" nuestro booleano pasa a false y por ende se
                 * termina el bucle y termina nuestro programa
                 */
                case "4":
                    bucle = false;
                    break;
                /**
                 * Acá en el default válida que sólo ingresemos datos válidos
                 *
                 */
                default:
                    System.out.println("Ingrese una opción válida!!");
            }
        } while (bucle);
    }

}
